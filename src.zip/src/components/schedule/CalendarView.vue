<script setup lang="ts">
import { computed } from "vue";
import FullCalendar from "@fullcalendar/vue3";

// ✅ v6에서는 index.css 경로 사용
import "@fullcalendar/core/main.css";
import "@fullcalendar/daygrid/main.css";
import "@fullcalendar/timegrid/main.css";

import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";

const props = defineProps({
  events: { type: Array, required: true },
  viewType: { type: String, default: "dayGridMonth" },
});

const safeViewType = computed(() => {
  const v = props.viewType?.trim?.();
  if (!v) return "dayGridMonth";
  const valid = ["dayGridMonth", "timeGridWeek", "timeGridDay"];
  return valid.includes(v) ? v : "dayGridMonth";
});
</script>

<template>
  <FullCalendar
    :plugins="[dayGridPlugin, timeGridPlugin, interactionPlugin]"
    :initialView="safeViewType"
    :events="props.events"
    :headerToolbar="false"
    height="auto"
  />
</template>

<style scoped>
:deep(.fc) {
  font-family: "Pretendard", sans-serif;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  padding: 12px;
}
</style>
