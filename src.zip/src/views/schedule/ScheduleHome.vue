<script setup lang="ts">
import { onMounted, ref, computed } from "vue";
import MilestoneCard from "@/components/schedule/MilestoneCard.vue";
import TaskList from "@/components/schedule/TaskList.vue";
import PersonalTodo from "@/components/schedule/PersonalTodo.vue";
import { useScheduleStore } from "@/stores/schedule";

const store = useScheduleStore();

const workspaceId = localStorage.getItem("workspaceId") || "";
store.setWorkspace(workspaceId);

onMounted(() => {
  store.loadAll();
});

const today = computed(() => {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}.${mm}.${dd}`;
});

const activeMilestoneIdx = ref(0);
const activeMilestone = computed(
  () => store.milestones[activeMilestoneIdx.value]
);

function nextMs() {
  if (activeMilestoneIdx.value < store.milestones.length - 1)
    activeMilestoneIdx.value++;
}
function prevMs() {
  if (activeMilestoneIdx.value > 0) activeMilestoneIdx.value--;
}
</script>

<template>
    <div class="tabs">
      <button class="tab active">일정 홈</button>
      <button class="tab" @click="$router.push('/schedule/project')">프로젝트 캘린더</button>
      <button class="tab" @click="$router.push('/schedule/shared')">공유 캘린더</button>
    </div>

    <div class="today">
      <span>Today</span>
      <strong>{{ today }}</strong>
    </div>

    <!-- ✅ 2행 2열 레이아웃 -->
    <div class="grid">
      <!-- 1️⃣ 왼쪽 위 : 마일스톤 -->
      <div class="card milestone">
        <div class="nav">
          <button @click="prevMs">◀</button>
          <div class="spacer"></div>
          <button @click="nextMs">▶</button>
        </div>
        <MilestoneCard
          v-if="activeMilestone"
          :name="activeMilestone.name"
          :dday="activeMilestone.dday"
          :progress="activeMilestone.progress"
        />
        <div v-else class="empty">진행 중인 마일스톤이 없습니다.</div>
      </div>

      <!-- 2️⃣ 오른쪽 위 : 개인 To-Do -->
      <div class="card todo">
        <PersonalTodo :items="store.todos" @toggle="store.toggleTodo" />
      </div>

      <!-- 3️⃣ 왼쪽 아래 : Task -->
      <div class="card task">
        <TaskList :items="store.tasks" @toggle="store.toggleTask" />
      </div>

      <!-- 4️⃣ 오른쪽 아래 : 추가 카드 -->
      <div class="card summary">
        <div class="empty">추가 기능 준비 중입니다.</div>
      </div>
    </div>
</template>

<style scoped>
/* 전체 컨테이너 */
.wrap {
  padding: 18px 20px;
  max-width: 1400px;
  margin: 0 auto;
}

/* 상단 탭 */
.tabs {
  display: flex;
  gap: 12px;
  border-bottom: 1px solid #e5e5e5;
  padding-bottom: 10px;
  margin-bottom: 18px;
}
.tab {
  border: none;
  background: none;
  padding: 8px 14px;
  border-bottom: 2px solid transparent;
  color: #888;
  font-weight: 600;
  cursor: pointer;
}
.tab.active {
  color: #111;
  border-color: #111;
}

/* 오늘 날짜 */
.today {
  color: #777;
  margin: 10px 0 20px;
  display: flex;
  gap: 10px;
  align-items: baseline;
}
.today strong {
  font-size: 14px;
  color: #111;
}

/* ✅ 2x2 그리드 레이아웃 */
.grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: repeat(2, 340px); /* 카드 높이 통일 */
  gap: 24px;
  justify-content: center;
  align-items: stretch;
}

/* ✅ 각 카드 공통 */
.card {
  position: relative;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.06);
  padding: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
}

/* ✅ 카드 내부 내용이 없을 때 */
.empty {
  color: #888;
  font-weight: 500;
}

/* ✅ 네비게이션 버튼 */
.nav {
  position: absolute;
  top: 8px;
  left: 8px;
  right: 8px;
  display: flex;
}
.nav .spacer {
  flex: 1;
}
.nav button {
  border: none;
  background: #fff;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.07);
  border-radius: 8px;
  width: 28px;
  height: 28px;
  cursor: pointer;
}

/* ✅ 반응형 (태블릿 이하일 때 1열) */
@media (max-width: 900px) {
  .grid {
    grid-template-columns: 1fr;
    grid-template-rows: auto;
  }
}
</style>
