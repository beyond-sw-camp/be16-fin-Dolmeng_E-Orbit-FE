import ProjectList from "../views/Project/ProjectList.vue";

export const projectRouter = [
    {
        path: "/project",
        name: "ProjectList",
        component: ProjectList
    }
];

