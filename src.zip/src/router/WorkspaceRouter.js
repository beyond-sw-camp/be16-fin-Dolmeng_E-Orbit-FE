import WorkspaceTest from "../views/Workspace/WorkspaceTest.vue";

export const workspaceRouter = [
    {
        path: "/workspace/test",
        name: "WorkspaceTest",
        component: WorkspaceTest
    }
];
