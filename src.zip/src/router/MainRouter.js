import Main from "../views/Main/Main.vue";


export const mainRouter = [
    {
        path: "/main",
        name: "Main",
        component: Main
    }
]