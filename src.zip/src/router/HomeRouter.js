import Home from "../views/Home/Home.vue";


export const homeRouter = [
    {
        path: "/",
        name: "Home",
        component: Home
    }
]