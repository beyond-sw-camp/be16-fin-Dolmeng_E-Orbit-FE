import ChatBotPage from "../views/ChatBot/ChatBotPage.vue";


export const chatBotRouter = [
    {
        path: "/chatbot/page",
        name: "ChatBotPage",
        component: ChatBotPage,
    },
]